package com.mycompany.callcenter1;

import java.util.LinkedList;

public class CallCenter {

    private Cola<Llamada> cola;
    private double tiempoTotal;
    private LinkedList<Integer> puntuaciones;

    public CallCenter() {
        cola = new Cola<Llamada>();
        tiempoTotal = 0;
        puntuaciones = new LinkedList<Integer>();
    }

    public void recibirLlamada(Llamada llamada) {
        if (llamada.getTipo() == Llamada.Tipo.prioritaria) {
            cola.enqueuePrioritario(llamada);
        } else {
            cola.enqueue(llamada);
        }
    }

    public Llamada atenderLlamada() {
        Llamada llamada = cola.dequeue();
        if (llamada == null) {
            System.out.println("No hay llamadas pendientes");
            return null;
        }
        tiempoTotal += llamada.getDuracion();
        puntuaciones.add(llamada.obtenerPuntuacion());
        return llamada;
    }

    public void cancelarLlamada() {
        Llamada llamada = cola.dequeue();
        if (llamada == null) {
            System.out.println("No hay llamadas para cancelar");
        } else {
            System.out.println("Llamada cancelada: " + llamada.getCliente());
        }
    }

    public void mostrarCola() {
        if (cola.empty()) {
            System.out.println("No hay llamadas pendientes");
            return;
        }
        System.out.println("Llamadas pendientes:");
        int cantidad = cola.size();
        for (int i = 0; i < cantidad; i++) {
            Llamada llamada = cola.dequeue();
            System.out.println((i + 1) + ". " + llamada.getCliente() + " - " + llamada.getDuracion() + " min");
            cola.enqueue(llamada);
        }
    }

    public double tiempoTotalPendiente() {
        double suma = 0;
        int cantidad = cola.size();
        for (int i = 0; i < cantidad; i++) {
            Llamada llamada = cola.dequeue();
            suma += llamada.getDuracion();
            cola.enqueue(llamada);
        }
        return suma;
    }

    public int llamadasPendientes() {
        return cola.size();
    }

    public void atenderTodas() {
        if (cola.empty()) {
            System.out.println("No hay llamadas pendientes");
            return;
        }
        while (!cola.empty()) {
            Llamada llamada = atenderLlamada();
            int puntuacion = puntuaciones.getLast();
            System.out.println("Atendido: " + llamada.getCliente()
                    + " | Duracion: " + llamada.getDuracion() + " min"
                    + " | Puntuacion: " + puntuacion);
        }
    }

    public int obtenerpromedio() {
        if (puntuaciones.isEmpty()) {
            return 0;
        }
        int suma = 0;
        for (int p : puntuaciones) {
            suma += p;
        }
        return (int) Math.round((double) suma / puntuaciones.size());
    }

    public double getTiempoTotal() {
        return tiempoTotal;
    }
}
