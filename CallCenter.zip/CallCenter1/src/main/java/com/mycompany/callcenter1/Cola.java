package com.mycompany.callcenter1;

public class Cola<T> {

    private class Nodo {
        T dato;
        Nodo siguiente;

        Nodo(T dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    private Nodo inicio;
    private Nodo fin;
    private int tamanio;

    public Cola() {
        inicio = null;
        fin = null;
        tamanio = 0;
    }

    public void enqueue(T dato) {
        Nodo nuevo = new Nodo(dato);
        if (empty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
        }
        tamanio++;
    }

    public T dequeue() {
        if (empty()) {
            return null;
        }
        T dato = inicio.dato;
        inicio = inicio.siguiente;
        if (inicio == null) {
            fin = null;
        }
        tamanio--;
        return dato;
    }

    public T peek() {
        if (empty()) {
            return null;
        }
        return inicio.dato;
    }

    public boolean empty() {
        return tamanio == 0;
    }

    public int size() {
        return tamanio;
    }

    public void enqueuePrioritario(T dato) {
        Nodo nuevo = new Nodo(dato);
        if (empty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            nuevo.siguiente = inicio;
            inicio = nuevo;
        }
        tamanio++;
    }
}
