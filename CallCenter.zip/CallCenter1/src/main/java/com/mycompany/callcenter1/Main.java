package com.mycompany.callcenter1;

public class Main {

    public static void main(String[] args) {
        System.out.println("===== PRUEBA DE LA COLA =====");
        Cola<String> colaPrueba = new Cola<String>();
        colaPrueba.enqueue("A");
        colaPrueba.enqueue("B");
        colaPrueba.enqueue("C");
        colaPrueba.enqueuePrioritario("Z");
        System.out.println("Tamanio: " + colaPrueba.size());
        System.out.println("Peek: " + colaPrueba.peek());
        System.out.println("Dequeue: " + colaPrueba.dequeue());
        System.out.println("Dequeue: " + colaPrueba.dequeue());
        System.out.println("Esta vacia: " + colaPrueba.empty());
        System.out.println("Tamanio: " + colaPrueba.size());

        System.out.println();
        System.out.println("===== CALL CENTER =====");
        CallCenter centro = new CallCenter();

        centro.recibirLlamada(new Llamada(1, "Juan Perez", Llamada.Tipo.normal, 5.5));
        centro.recibirLlamada(new Llamada(2, "Maria Lopez", Llamada.Tipo.normal, 3.0));
        centro.recibirLlamada(new Llamada(3, "Carlos Ruiz", Llamada.Tipo.prioritaria, 8.2));
        centro.recibirLlamada(new Llamada(4, "Ana Torres", Llamada.Tipo.normal, 2.5));
        centro.recibirLlamada(new Llamada(5, "Luis Gomez", Llamada.Tipo.prioritaria, 6.0));

        centro.mostrarCola();
        System.out.println("Llamadas pendientes: " + centro.llamadasPendientes());
        System.out.println("Tiempo total pendiente: " + centro.tiempoTotalPendiente() + " min");

        System.out.println();
        System.out.println("--- Atender una llamada ---");
        Llamada atendida = centro.atenderLlamada();
        System.out.println("Se atendio a: " + atendida.getCliente());

        System.out.println();
        System.out.println("--- Cancelar una llamada ---");
        centro.cancelarLlamada();

        System.out.println();
        centro.mostrarCola();
        System.out.println("Llamadas pendientes: " + centro.llamadasPendientes());

        System.out.println();
        System.out.println("--- Atender todas ---");
        centro.atenderTodas();

        System.out.println();
        System.out.println("Llamadas pendientes: " + centro.llamadasPendientes());
        System.out.println("Tiempo total atendido: " + centro.getTiempoTotal() + " min");
        System.out.println("Promedio de puntuacion: " + centro.obtenerpromedio());

        System.out.println();
        System.out.println("--- Cola vacia ---");
        centro.atenderLlamada();
        centro.cancelarLlamada();
        centro.mostrarCola();
    }
}
